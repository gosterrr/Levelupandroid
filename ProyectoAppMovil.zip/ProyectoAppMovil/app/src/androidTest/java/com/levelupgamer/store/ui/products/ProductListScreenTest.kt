//*****   Debe ser instalado en: app/src/androidTest/java/com/levelupgamer/store/ui/products/ProductListScreenTest.kt

//--------------------------------------------------------------------------------------
// Este código implementa una prueba de interfaz de usuario (UI) para la ProductListScreen.
// PROPÓSITO PRINCIPAL
// Validar que los componentes visuales de la pantalla renderizan y muestran correctamente
// los datos (nombres de productos) proporcionados por el ViewModel.
//
// Compose Test Rule: Crea un entorno de prueba para componentes Compose en un dispositivo/emulador.
// ViewModel Real: Usa una instancia real de ProductListViewModel.
// Datos Fake: Inyecta una lista simulada de productos para controlar el entorno del test.
// Aserciones Visuales: Verifica que los nodos de texto con los nombres de los productos existen y son visibles en la pantalla.
//--------------------------------------------------------------------------------------

// Declara el paquete donde se encuentra la clase de test
package com.levelupgamer.store.ui.products

// Importa la actividad base para el entorno de prueba
import androidx.activity.ComponentActivity
// Importa las reglas y funciones de test de Compose
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
// Importa el modelo de datos Product
import com.levelupgamer.store.data.model.Product
// Importa los recursos de la app (para imágenes)
import com.example.proyectoappmovil.R
// Importa el ViewModel que vamos a probar
import org.junit.Rule
import org.junit.Test

// Clase de tests para ProductListScreen
class ProductListScreenTest {

    // Crea una regla de test para Compose que lanza una actividad vacía
    @get:Rule
    val composeTestRule = createAndroidComposeRule<ComponentActivity>()

    // Test que verifica que los nombres de los productos se muestran en la pantalla
    @Test
    fun product_names_should_be_displayed_on_screen() {
        // --- PREPARACIÓN ---
        // 1. Crea una lista falsa de productos para el test
        val fakeProducts = listOf(
            Product(1, "RTX 4090 Founders Edition", "Descripción 1", 1900000.0, R.drawable.levelupgamer, "Tarjetas Gráficas"),
            Product(10, "Intel Core i9-13900K", "Descripción 2", 650000.0, R.drawable.levelupgamer, "Procesadores")
        )

        // 2. Crea una instancia del ViewModel y le inyecta los datos falsos
        // NOTA: Para que esto funcione, `_products` en el ViewModel debe ser `internal`, no `private`.
        val fakeViewModel = ProductListViewModel(category = "TestCategory").apply {
            _products.value = fakeProducts
        }

        // --- ACCIÓN ---
        // 3. Renderiza la pantalla `ProductListScreen` con el ViewModel falso
        // NOTA: Para que esto funcione, la pantalla debe aceptar el ViewModel como parámetro.
        composeTestRule.setContent {
            ProductListScreen(
                category = "TestCategory",
                viewModel = fakeViewModel,
                onProductClick = {},
                onBack = {}
            )
        }

        // --- ASERCIÓN ---
        // 4. Verifica que los nombres de los productos son visibles en la pantalla
        composeTestRule.onNodeWithText("RTX 4090 Founders Edition").assertIsDisplayed()
        composeTestRule.onNodeWithText("Intel Core i9-13900K").assertIsDisplayed()
    }
}
