package com.levelupgamer.store.ui.products

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ProductDetailViewModel : ViewModel() {

    private val productRepository: ProductRepository

    private val _product = MutableStateFlow<Product?>(null)
    val product: StateFlow<Product?> = _product.asStateFlow()

    init {
        val productDao = ProductDao()
        productRepository = ProductRepository(productDao)
    }

    fun loadProduct(productId: Int) {
        _product.value = productRepository.getAllProducts().find { it.id == productId }
    }
}
