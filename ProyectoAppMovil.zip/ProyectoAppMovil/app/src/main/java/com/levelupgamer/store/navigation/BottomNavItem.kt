package com.levelupgamer.store.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.proyectoappmovil.R

sealed class BottomNavItem(
    val route: String,
    val resourceId: Int,
    val icon: ImageVector
) {
    object Home : BottomNavItem("home_welcome", R.string.home, Icons.Default.Home)
    object Profile : BottomNavItem("profile", R.string.profile, Icons.Default.Person)
    object Cart : BottomNavItem("cart", R.string.my_cart, Icons.Default.ShoppingCart)
    object Shipping : BottomNavItem("shipping", R.string.shipping, Icons.Default.LocalShipping)
}
