package com.levelupgamer.store.ui.admin

import androidx.lifecycle.ViewModel
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdminProductViewModel : ViewModel() {

    private val productRepository: ProductRepository
    private val productDao: ProductDao

    private val _products: MutableStateFlow<List<Product>>
    val products: StateFlow<List<Product>>

    init {
        productDao = ProductDao()
        productRepository = ProductRepository(productDao)
        _products = MutableStateFlow(productRepository.getAllProducts())
        products = _products.asStateFlow()
    }

    private fun refreshProducts() {
        _products.value = productRepository.getAllProducts()
    }

    fun addProduct(product: Product) {
        // In a real app, this would be a DAO operation.
        // Here, we just update the in-memory list for now.
        val currentList = _products.value.toMutableList()
        currentList.add(product)
        _products.value = currentList
    }

    fun updateProduct(product: Product) {
        val currentList = _products.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == product.id }
        if (index != -1) {
            currentList[index] = product
            _products.value = currentList
        }
    }

    fun deleteProduct(productId: Int) {
        val currentList = _products.value.toMutableList()
        currentList.removeAll { it.id == productId }
        _products.value = currentList
    }

    fun getProductById(productId: Int): Product? {
        return _products.value.find { it.id == productId }
    }
}
