package com.levelupgamer.store.data.model

data class Credential(
    val email: String,
    val pass: String
)
