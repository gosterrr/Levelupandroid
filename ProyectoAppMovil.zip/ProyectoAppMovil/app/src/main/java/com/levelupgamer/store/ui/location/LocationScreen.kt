package com.levelupgamer.store.ui.location

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun LocationScreen() {
    val application = LocalContext.current.applicationContext as Application
    val locationViewModel: LocationViewModel = viewModel(factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application))
    val uiState by locationViewModel.uiState.collectAsState()
    val context = LocalContext.current

    // --- New, robust permission handling using modern AndroidX Activity APIs ---
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            hasLocationPermission = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true || 
                                  permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        }
    )

    // Request permissions immediately when the screen is shown, if not already granted
    LaunchedEffect(Unit) {
        if (!hasLocationPermission) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (hasLocationPermission) {
            // If permissions are granted, show the main content
            Button(onClick = { locationViewModel.fetchLocationAndAddress() }) {
                Text("Verificar mi Ubicación de Envío")
            }
            Spacer(modifier = Modifier.height(24.dp))

            if (uiState.isLoading) {
                CircularProgressIndicator()
            } else {
                uiState.errorMessage?.let {
                    Text(text = it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                }
                uiState.address?.let {
                    Card(elevation = CardDefaults.cardElevation(4.dp)) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("¡Buenas noticias!", style = MaterialTheme.typography.titleLarge)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Ofrecemos envío a tu zona:")
                            Text(it, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                        }
                    }
                } ?: uiState.location?.let {
                     Text(text = "Ubicación: Lat: ${it.latitude}, Lon: ${it.longitude}")
                }
            }
        } else {
            // If permissions are not (yet) granted, show a rationale and a button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Necesitamos tu permiso de ubicación para verificar la disponibilidad de envío.",
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { 
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    ) 
                }) {
                    Text("Conceder Permiso")
                }
            }
        }
    }
}
