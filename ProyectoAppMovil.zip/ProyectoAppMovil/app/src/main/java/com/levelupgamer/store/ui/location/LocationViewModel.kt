package com.levelupgamer.store.ui.location

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.levelupgamer.store.data.repository.LocationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LocationUiState(
    val location: Location? = null,
    val address: String? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    private val locationRepository = LocationRepository(application)

    private val _uiState = MutableStateFlow(LocationUiState())
    val uiState: StateFlow<LocationUiState> = _uiState.asStateFlow()

    fun fetchLocationAndAddress() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val location = locationRepository.getUserLocation()
                _uiState.value = _uiState.value.copy(location = location)

                if (location != null) {
                    val address = locationRepository.getAddressFromCoordinates(location.latitude, location.longitude)
                    _uiState.value = _uiState.value.copy(address = address, isLoading = false)
                } else {
                    _uiState.value = _uiState.value.copy(errorMessage = "No se pudo obtener la ubicación. Asegúrate de tener el GPS activado.", isLoading = false)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Error: ${e.message}", isLoading = false)
            }
        }
    }
}
