package com.levelupgamer.store.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

// Defines the structure of the API response we care about
data class GeocodingResponse(
    @SerializedName("display_name")
    val displayName: String
)

// Defines the API endpoints
interface GeocodingApiService {
    @GET("reverse")
    suspend fun reverseGeocode(
        @Query("lat") latitude: Double,
        @Query("lon") longitude: Double,
        @Query("format") format: String = "json"
    ): Response<GeocodingResponse>
}
