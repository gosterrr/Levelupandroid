//*****   Debe ser instalado en: app/src/test/java/com/levelupgamer/store/data/repository/CartDaoTest.kt

//--------------------------------------------------------------------------------------
// Este código implementa una prueba unitaria para el CartDao (simulado en memoria).
// PROPÓSITO PRINCIPAL
// Validar que la lógica de negocio del DAO (añadir, eliminar, limpiar) funciona correctamente,
// manipulando el estado y verificando los resultados a través de su StateFlow.
//
// Configuración de Corrutinas: Usa TestDispatcher para controlar la ejecución en tests.
// DAO Real (Simulado): Testea la instancia real de nuestro CartDao en memoria.
// Aserciones Claras: Confirma que el estado del carrito se actualiza como se espera después de cada acción.
// Ciclo de Vida de Tests: Usa @BeforeEach para asegurar que cada prueba se ejecute en un estado limpio.
//--------------------------------------------------------------------------------------

// Declara el paquete donde se encuentra la clase de test
package com.levelupgamer.store.data.repository

// Importa el modelo de datos Product
import com.levelupgamer.store.data.model.Product
// Importa los recursos de la app para las imágenes de prueba
import com.example.proyectoappmovil.R
// Importa el dispatcher para corrutinas
import kotlinx.coroutines.Dispatchers
// Importa la anotación para APIs experimentales de corrutinas
import kotlinx.coroutines.ExperimentalCoroutinesApi
// Importa la función `first` para obtener el primer valor de un Flow
import kotlinx.coroutines.flow.first
// Importa el dispatcher de test sin confinamiento
import kotlinx.coroutines.test.UnconfinedTestDispatcher
// Importa función para resetear el dispatcher principal
import kotlinx.coroutines.test.resetMain
// Importa el builder para tests de corrutinas
import kotlinx.coroutines.test.runTest
// Importa función para establecer el dispatcher principal de test
import kotlinx.coroutines.test.setMain
// Importa la clase Assert para las aserciones
import org.junit.Assert.*
// Importa la anotación After
import org.junit.After
// Importa la anotación Before
import org.junit.Before
// Importa la anotación Test
import org.junit.Test

// Anotación para indicar uso de APIs experimentales de corrutinas
@OptIn(ExperimentalCoroutinesApi::class)
// Clase de tests para CartDao
class CartDaoTest {

    // Crea un dispatcher de test para controlar la ejecución de corrutinas
    private val testDispatcher = UnconfinedTestDispatcher()

    // Declara una instancia del DAO que vamos a probar
    private lateinit var cartDao: CartDao

    // Crea productos de ejemplo que se usarán en las pruebas
    private val sampleProduct1 = Product(1, "Test PC Gamer", "Descripción", 1000.0, R.drawable.levelupgamer, "PCs")
    private val sampleProduct2 = Product(2, "Test Keyboard", "Descripción", 200.0, R.drawable.levelupgamer, "Keyboards")

    // Método que se ejecuta antes de cada test
    @Before
    fun setUp() {
        // Establece el dispatcher principal para que las corrutinas se ejecuten en el hilo de test
        Dispatchers.setMain(testDispatcher)
        // Crea una instancia nueva y limpia del DAO antes de cada prueba
        cartDao = CartDao()
    }

    // Método que se ejecuta después de cada test
    @After
    fun tearDown() {
        // Restaura el dispatcher principal original para no afectar otros tests
        Dispatchers.resetMain()
    }

    // Test que verifica que `insertItem` y `getCartItems` funcionan correctamente
    @Test
    fun `insertItem and getCartItems should add item to flow`() = runTest {
        // --- ACCIÓN ---
        // Inserta un producto en el carrito con cantidad 1
        cartDao.insertItem(sampleProduct1, 1)

        // --- VERIFICACIÓN ---
        // Obtiene el valor actual del Flow de ítems del carrito
        val cartItems = cartDao.getCartItems().first()

        // --- ASERCIÓN ---
        // Comprueba que el carrito no está vacío
        assertTrue("El carrito debería contener ítems", cartItems.isNotEmpty())
        // Comprueba que el carrito contiene el producto que añadimos
        assertTrue("El carrito debería contener el producto añadido", cartItems.containsKey(sampleProduct1))
        // Comprueba que la cantidad del producto es la correcta
        assertEquals("La cantidad debería ser 1", 1, cartItems[sampleProduct1])
    }

    // Test que verifica que `deleteItem` elimina el producto correcto
    @Test
    fun `deleteItem should remove the item from the cart`() = runTest {
        // --- PREPARACIÓN ---
        // Añade dos productos al carrito para empezar
        cartDao.insertItem(sampleProduct1, 1)
        cartDao.insertItem(sampleProduct2, 2)

        // --- ACCIÓN ---
        // Elimina el primer producto
        cartDao.deleteItem(sampleProduct1)

        // --- VERIFICACIÓN ---
        // Obtiene el estado actual del carrito
        val cartItems = cartDao.getCartItems().first()

        // --- ASERCIÓN ---
        // Comprueba que el tamaño del carrito ahora es 1
        assertEquals("El carrito solo debería contener un ítem", 1, cartItems.size)
        // Comprueba que el producto eliminado ya no está
        assertFalse("El carrito no debería contener el producto eliminado", cartItems.containsKey(sampleProduct1))
        // Comprueba que el otro producto sigue en el carrito
        assertTrue("El carrito todavía debería contener el otro producto", cartItems.containsKey(sampleProduct2))
    }

    // Test que verifica que `clearCart` vacía el carrito por completo
    @Test
    fun `clearCart should empty all items`() = runTest {
        // --- PREPARACIÓN ---
        // Añade productos al carrito
        cartDao.insertItem(sampleProduct1, 1)
        cartDao.insertItem(sampleProduct2, 2)

        // --- ACCIÓN ---
        // Llama a la función para limpiar el carrito
        cartDao.clearCart()

        // --- VERIFICACIÓN ---
        // Obtiene el estado final del carrito
        val cartItems = cartDao.getCartItems().first()

        // --- ASERCIÓN ---
        // Comprueba que el carrito está vacío
        assertTrue("El carrito debería estar vacío después de limpiarlo", cartItems.isEmpty())
    }
}
