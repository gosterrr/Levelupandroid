//*****   Debe ser instalado en: app/src/test/java/com/levelupgamer/store/data/repository/ProductDaoTest.kt

//--------------------------------------------------------------------------------------
// Este código implementa una prueba unitaria para el ProductDao (simulado en memoria).
// PROPÓSITO PRINCIPAL
// Validar que la lógica de negocio del DAO (obtener todos los productos y filtrar por categoría)
// funciona correctamente, devolviendo los datos esperados desde la lista en memoria.
//
// DAO Real (Simulado): Testea la instancia real de nuestro ProductDao en memoria.
// Aserciones Claras: Confirma que las listas devueltas tienen el tamaño y contenido correctos.
// No usa Corrutinas: Como los métodos del DAO son síncronos, no se necesita configuración de corrutinas.
//--------------------------------------------------------------------------------------

// Declara el paquete donde se encuentra la clase de test
package com.levelupgamer.store.data.repository

// Importa las funciones de aserción para tests
import org.junit.Assert.*
// Importa la anotación Before
import org.junit.Before
// Importa la anotación Test
import org.junit.Test

// Clase de tests para ProductDao
class ProductDaoTest {

    // Declara una instancia del DAO que vamos a probar
    private lateinit var productDao: ProductDao

    // Método que se ejecuta antes de cada test
    @Before
    fun setup() {
        // Crea una instancia nueva y limpia del DAO antes de cada prueba
        productDao = ProductDao()
    }

    // Test que verifica que `getAllProducts` retorna todos los productos definidos
    @Test
    fun `getAllProducts should return all defined products`() {
        // --- ACCIÓN ---
        // Llama a la función para obtener todos los productos
        val products = productDao.getAllProducts()

        // --- ASERCIÓN ---
        // Comprueba que el número de productos devueltos es el esperado (12 en nuestro caso)
        assertEquals("Debería retornar 12 productos en total", 12, products.size)
    }

    // Test que verifica que `getProductsByCategory` filtra correctamente
    @Test
    fun `getProductsByCategory should return only products from that category`() {
        // --- ACCIÓN ---
        // Pide los productos de la categoría "Tarjetas Gráficas"
        val graphicsCards = productDao.getProductsByCategory("Tarjetas Gráficas")

        // Pide los productos de la categoría "Procesadores"
        val processors = productDao.getProductsByCategory("Procesadores")

        // --- ASERCIÓN ---
        // Comprueba que el número de tarjetas gráficas es correcto (3)
        assertEquals("Debería haber 3 tarjetas gráficas", 3, graphicsCards.size)
        // Comprueba que todos los productos en la lista son de la categoría correcta
        assertTrue("Todos los productos deberían ser Tarjetas Gráficas", graphicsCards.all { it.category == "Tarjetas Gráficas" })

        // Comprueba que el número de procesadores es correcto (3)
        assertEquals("Debería haber 3 procesadores", 3, processors.size)
        // Comprueba que todos los productos en la lista son de la categoría correcta
        assertTrue("Todos los productos deberían ser Procesadores", processors.all { it.category == "Procesadores" })
    }

    // Test que verifica que una categoría inexistente retorna una lista vacía
    @Test
    fun `getProductsByCategory with non-existent category should return empty list`() {
        // --- ACCIÓN ---
        // Pide los productos de una categoría que no existe
        val nonExistentCategoryProducts = productDao.getProductsByCategory("Categoría Inexistente")

        // --- ASERCIÓN ---
        // Comprueba que la lista devuelta está vacía
        assertTrue("La lista debería estar vacía para una categoría que no existe", nonExistentCategoryProducts.isEmpty())
    }
}
