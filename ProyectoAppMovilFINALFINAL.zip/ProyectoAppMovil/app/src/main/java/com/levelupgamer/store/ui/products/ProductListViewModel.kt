package com.levelupgamer.store.ui.products

import androidx.lifecycle.ViewModel
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// The ViewModel now receives the ProductDao via its constructor
class ProductListViewModel(category: String, productDao: ProductDao) : ViewModel() {

    private val productRepository: ProductRepository

    // _products remains internal to allow testing
    internal val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    init {
        // The repository is now initialized with the DAO passed from the factory
        this.productRepository = ProductRepository(productDao)
        _products.value = productRepository.getProductsByCategory(category)
    }
}
