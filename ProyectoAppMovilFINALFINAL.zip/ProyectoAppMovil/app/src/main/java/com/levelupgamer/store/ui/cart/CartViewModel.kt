package com.levelupgamer.store.ui.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.CartDao
import com.levelupgamer.store.data.repository.CartRepository
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CartUiState(
    val items: Map<Product, Int> = emptyMap(),
    val total: Double = 0.0
)

// The ViewModel now receives the DAOs via its constructor
class CartViewModel(productDao: ProductDao, cartDao: CartDao) : ViewModel() {

    private val productRepository: ProductRepository
    private val cartRepository: CartRepository

    val uiState: StateFlow<CartUiState>

    init {
        // The repositories are now initialized with the DAOs passed from the factory
        this.productRepository = ProductRepository(productDao)
        this.cartRepository = CartRepository(cartDao)

        uiState = cartRepository.getCartItems().map { items ->
            val total = items.entries.sumOf { (product, quantity) -> product.price * quantity }
            CartUiState(items, total)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CartUiState()
        )
    }

    fun addToCart(productId: Int) {
        viewModelScope.launch {
            productRepository.getAllProducts().find { it.id == productId }?.let {
                cartRepository.addToCart(it)
            }
        }
    }

    fun removeFromCart(product: Product) {
        viewModelScope.launch {
            cartRepository.removeFromCart(product)
        }
    }

    fun checkout() {
        viewModelScope.launch {
            cartRepository.clearCart()
        }
    }
}
