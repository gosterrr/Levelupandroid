package com.levelupgamer.store.data.repository

import com.levelupgamer.store.data.model.Product
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class CartRepository(private val cartDao: CartDao) {

    fun getCartItems(): Flow<Map<Product, Int>> {
        return cartDao.getCartItems()
    }

    suspend fun addToCart(product: Product) {
        val existingItem = cartDao.getItemById(product.id)
        val currentQuantity = if (existingItem != null) cartDao.getCartItems().first()[existingItem] ?: 0 else 0
        cartDao.insertItem(product, currentQuantity + 1)
    }

    suspend fun removeFromCart(product: Product) {
        cartDao.deleteItem(product)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }
}
