package com.levelupgamer.store.data.repository

import com.levelupgamer.store.data.model.Product

/**
 * The repository is now clean. It doesn't know where the data comes from.
 * It just asks its DAO for the data.
 */
class ProductRepository(private val productDao: ProductDao) {

    fun getAllProducts(): List<Product> {
        return productDao.getAllProducts()
    }

    fun getProductsByCategory(category: String): List<Product> {
        return productDao.getProductsByCategory(category)
    }
}
