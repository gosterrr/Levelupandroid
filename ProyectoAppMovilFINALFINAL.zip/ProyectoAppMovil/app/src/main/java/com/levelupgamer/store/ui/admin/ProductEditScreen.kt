package com.levelupgamer.store.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.levelupgamer.store.data.model.Product
import com.example.proyectoappmovil.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductEditScreen(
    product: Product?,
    onSave: (Product) -> Unit,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }

    // This LaunchedEffect will run once when the screen is displayed.
    // If a product is passed for editing, it pre-fills the form fields.
    LaunchedEffect(product) {
        product?.let {
            name = it.name
            description = it.description
            price = it.price.toString()
            category = it.category
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (product == null) stringResource(id = R.string.add_product) else stringResource(id = R.string.edit_product)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(id = R.string.back))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(stringResource(id = R.string.product_name)) },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text(stringResource(id = R.string.product_description)) },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = price,
                onValueChange = { price = it },
                label = { Text(stringResource(id = R.string.price)) },
                // Corrected KeyboardType for recent Compose versions
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
             OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("Categoría") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val priceDouble = price.toDoubleOrNull() ?: 0.0
                    // If we are editing, we use the original product's ID and image.
                    // If we are adding, we generate a new ID and use a default image.
                    val newOrUpdatedProduct = Product(
                        id = product?.id ?: (System.currentTimeMillis().toInt()), // Preserve original ID if editing
                        name = name,
                        description = description,
                        price = priceDouble,
                        category = category,
                        imageRes = product?.imageRes ?: R.drawable.levelupgamer // Preserve original image
                    )
                    onSave(newOrUpdatedProduct)
                },
                enabled = name.isNotBlank() && price.isNotBlank() && category.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(stringResource(id = R.string.save))
            }
        }
    }
}
