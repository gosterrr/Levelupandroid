package com.levelupgamer.store.ui.products

import androidx.lifecycle.ViewModel
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// The ViewModel now receives the productId and the ProductDao via its constructor
class ProductDetailViewModel(productId: Int, productDao: ProductDao) : ViewModel() {

    private val productRepository: ProductRepository

    private val _product = MutableStateFlow<Product?>(null)
    val product: StateFlow<Product?> = _product.asStateFlow()

    init {
        // The repository is now initialized with the shared DAO
        this.productRepository = ProductRepository(productDao)
        // The product is loaded immediately upon creation
        _product.value = productRepository.getAllProducts().find { it.id == productId }
    }
}
