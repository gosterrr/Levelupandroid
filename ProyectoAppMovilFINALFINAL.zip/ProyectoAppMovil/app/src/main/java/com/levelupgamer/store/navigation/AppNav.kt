package com.levelupgamer.store.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navigation
import com.levelupgamer.store.data.model.UserRole
import com.levelupgamer.store.data.repository.*
import com.levelupgamer.store.ui.admin.*
import com.levelupgamer.store.ui.cart.CartScreen
import com.levelupgamer.store.ui.cart.CartViewModel
import com.levelupgamer.store.ui.cart.CartViewModelFactory
import com.levelupgamer.store.ui.home.CategoryScreen
import com.levelupgamer.store.ui.home.HomeScreen
import com.levelupgamer.store.ui.location.LocationScreen
import com.levelupgamer.store.ui.login.ForgotPasswordScreen
import com.levelupgamer.store.ui.login.LoginScreen
import com.levelupgamer.store.ui.login.LoginViewModel
import com.levelupgamer.store.ui.login.RegisterScreen
import com.levelupgamer.store.ui.products.*
import com.levelupgamer.store.ui.profile.ProfileScreen
import com.example.proyectoappmovil.R

@Composable
fun AppNav() {
    val navController = rememberNavController()

    // --- SINGLE SOURCE OF TRUTH FOR DATA ---
    val productDao = remember { ProductDao() }
    val cartDao = remember { CartDao() }

    // Create shared ViewModels using Factories to inject the shared DAOs
    val adminViewModel: AdminProductViewModel = viewModel(factory = AdminProductViewModelFactory(productDao))
    val cartViewModel: CartViewModel = viewModel(factory = CartViewModelFactory(productDao, cartDao))

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            val showBottomBar = currentDestination?.hierarchy?.any { it.route?.startsWith("main_flow") == true } == true

            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.border(width = 1.dp, color = MaterialTheme.colorScheme.primary),
                    containerColor = MaterialTheme.colorScheme.background
                ) {
                    val items = listOf(BottomNavItem.Home, BottomNavItem.Shipping, BottomNavItem.Profile, BottomNavItem.Cart)
                    items.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = null) },
                            label = { Text(stringResource(id = screen.resourceId)) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "login",
            modifier = Modifier.padding(innerPadding),
            enterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, animationSpec = tween(700)) },
            exitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Right, animationSpec = tween(700)) }
        ) {
            composable("login") { 
                val loginViewModel: LoginViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                            @Suppress("UNCHECKED_CAST")
                            return LoginViewModel(AuthRepository()) as T
                        }
                        throw IllegalArgumentException("Unknown ViewModel class")
                    }
                })
                LoginScreen(
                    viewModel = loginViewModel,
                    onLoginSuccess = { user ->
                        val destination = if (user.role == UserRole.ADMIN) "admin_flow/${user.username}" else "main_flow/${user.username}"
                        navController.navigate(destination) {
                            popUpTo("login") { inclusive = true }
                        }
                    },
                    onRegisterClick = { navController.navigate("register") },
                    onForgotPasswordClick = { navController.navigate("forgot_password") }
                )
             }
            composable("register") { /* ... */ }
            composable("forgot_password") { /* ... */ }

            navigation(startDestination = BottomNavItem.Home.route, route = "main_flow/{username}") { 
                composable(BottomNavItem.Home.route) { backStackEntry ->
                    val username = remember(backStackEntry) { 
                        navController.getBackStackEntry("main_flow/{username}").arguments?.getString("username") ?: ""
                    }
                    HomeScreen(username = username, onViewCatalog = { navController.navigate("categories") })
                }
                composable(BottomNavItem.Shipping.route) { LocationScreen() }
                composable("categories") {
                    CategoryScreen(
                        onCategoryClick = { category -> navController.navigate("products/$category") },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable("products/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: ""
                    ProductListScreen(
                        category = category,
                        viewModel = viewModel(factory = ProductListViewModelFactory(category, productDao)),
                        onProductClick = { productId -> navController.navigate("productDetail/$productId") },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable("productDetail/{productId}") { backStackEntry ->
                    val productId = backStackEntry.arguments?.getInt("productId") ?: 0
                    ProductDetailScreen(
                        productId = productId,
                        viewModel = viewModel(factory = ProductDetailViewModelFactory(productId, productDao)),
                        onAddToCart = { cartViewModel.addToCart(it) },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(BottomNavItem.Profile.route) {
                    val username = remember(it) { 
                        navController.getBackStackEntry("main_flow/{username}").arguments?.getString("username") ?: ""
                    }
                    ProfileScreen(email = username, onLogout = {
                        navController.navigate("login") {
                            popUpTo("main_flow") { inclusive = true }
                        }
                    })
                }
                composable(BottomNavItem.Cart.route) { CartScreen(viewModel = cartViewModel) }
            }

            navigation(startDestination = "admin_panel", route = "admin_flow/{username}") { 
                composable("admin_panel") { backStackEntry ->
                    val username = remember(backStackEntry) { 
                        navController.getBackStackEntry("admin_flow/{username}").arguments?.getString("username") ?: ""
                    }
                    AdminPanelScreen(
                        username = username,
                        viewModel = adminViewModel,
                        onAddProduct = { navController.navigate("admin_edit_product/-1") },
                        onEditProduct = { productId -> navController.navigate("admin_edit_product/$productId") },
                        onLogout = { 
                             navController.navigate("login") {
                                popUpTo("admin_flow") { inclusive = true }
                            }
                        }
                    )
                }
                composable("admin_edit_product/{productId}") { backStackEntry ->
                    val productId = backStackEntry.arguments?.getInt("productId")
                    val product = if (productId != null && productId != -1) adminViewModel.getProductById(productId) else null
                    ProductEditScreen(
                        product = product,
                        onSave = {
                            if (product == null) adminViewModel.addProduct(it) else adminViewModel.updateProduct(it)
                            navController.popBackStack()
                        },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
