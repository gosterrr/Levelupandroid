package com.levelupgamer.store.ui.admin

import androidx.lifecycle.ViewModel
import com.levelupgamer.store.data.model.Product
import com.levelupgamer.store.data.repository.ProductDao
import com.levelupgamer.store.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// The ViewModel now receives the SHARED ProductDao via its constructor
class AdminProductViewModel(private val productDao: ProductDao) : ViewModel() {

    private val productRepository: ProductRepository

    // This StateFlow now gets its initial value from the shared DAO
    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    init {
        this.productRepository = ProductRepository(productDao)
        loadProducts()
    }

    private fun loadProducts() {
        _products.value = productRepository.getAllProducts()
    }

    // IMPORTANT: These methods now modify the list INSIDE THE SHARED DAO
    fun addProduct(product: Product) {
        productDao.addProduct(product) // This now modifies the single source of truth
        loadProducts() // Corrected function name
    }

    fun updateProduct(product: Product) {
        productDao.updateProduct(product) // This now modifies the single source of truth
        loadProducts() // Corrected function name
    }

    fun deleteProduct(productId: Int) {
        productDao.deleteProduct(productId) // This now modifies the single source of truth
        loadProducts() // Corrected function name
    }

    fun getProductById(productId: Int): Product? {
        return productRepository.getAllProducts().find { it.id == productId }
    }
}
