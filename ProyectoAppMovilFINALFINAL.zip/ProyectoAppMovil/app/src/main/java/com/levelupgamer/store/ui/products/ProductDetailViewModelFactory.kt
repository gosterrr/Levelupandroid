package com.levelupgamer.store.ui.products

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.levelupgamer.store.data.repository.ProductDao

class ProductDetailViewModelFactory(
    private val productId: Int,
    private val productDao: ProductDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProductDetailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProductDetailViewModel(productId, productDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
