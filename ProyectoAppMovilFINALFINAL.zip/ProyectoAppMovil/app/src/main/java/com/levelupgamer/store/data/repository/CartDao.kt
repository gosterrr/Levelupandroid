package com.levelupgamer.store.data.repository

import com.levelupgamer.store.data.model.Product
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * This is a FAKE DAO that simulates database behavior in memory.
 * It maintains the architecture (Repository -> DAO) without the build issues.
 */
class CartDao {

    private val _cartItems = MutableStateFlow<Map<Product, Int>>(emptyMap())

    fun getCartItems(): Flow<Map<Product, Int>> {
        return _cartItems.asStateFlow()
    }

    suspend fun getItemById(productId: Int): Product? {
        return _cartItems.value.keys.find { it.id == productId }
    }

    suspend fun insertItem(product: Product, quantity: Int) {
        val currentItems = _cartItems.value.toMutableMap()
        currentItems[product] = quantity
        _cartItems.value = currentItems
    }

    suspend fun deleteItem(product: Product) {
        val currentItems = _cartItems.value.toMutableMap()
        currentItems.remove(product)
        _cartItems.value = currentItems
    }

    suspend fun clearCart() {
        _cartItems.value = emptyMap()
    }
}
